package program1_2;

public class TestRectangle {


	/**
	 * The start point of the program
	 * 
	 * @param args
	 * 
	 */
	public static void main(String[] args) {
		// Create two objects of this class, r1 and r2. Show the output of both the
		// constructor sand all method of these two objects
		int n=0,i=0;
		
		Rectangle r1 = new Rectangle();
		Rectangle r2 = new Rectangle(n,i);
		Rectangle r3 = new Rectangle(n,i);
		Rectangle r4 = new Rectangle(n,i); 
		Rectangle r5 = new Rectangle(n,i);
		
		r1.printData();
		r1.printArea();
		
		r2.input();
		r2.printData();
		r2.printArea();
		
		r3.input();
		r3.printData();
		r3.printArea();
		
		r4.input();
		r4.printData();
		r4.printArea();
		
		r5.input();
		r5.printData();
		r5.printArea();

	}
}