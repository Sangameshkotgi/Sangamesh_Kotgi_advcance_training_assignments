package program1_2;

import java.util.Scanner;
class Rectangle {
	private int length;
	private int breadth;


	/**
	 * (a) default constructor
	 */
	public Rectangle() {
	}


	/**
	 * constructor to pass on length and breadth of a Rectangle
	 * 
	 * @param length
	 * @param breadth
	 */
	public Rectangle(int length, int breadth) {
		this.length = length;
		this.breadth = breadth;
	}
	
	public void input() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter length of rectangle: ");
        length = in.nextInt();
        System.out.print("Enter breadth of rectangle: ");
        breadth = in.nextInt();
    }


	/**
	 * Add a method printData( ) to print the two information about the rectangle in
	 * console.
	 */
	public void printData() {
		System.out.println("Length: " + length);
		System.out.println("Breadth: " + breadth);
	}


	/**
	 * method printArea() and printPerimeter()
	 */
	public void printArea() {
		int area = length * breadth;
		System.out.println("Area: " + area);
	}

}
