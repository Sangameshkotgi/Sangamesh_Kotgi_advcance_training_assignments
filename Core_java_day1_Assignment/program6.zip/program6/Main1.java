package program6;

import java.io.*;
import java.util.ArrayList;

class Main1{
	public static void main (String[] args) {
		ArrayList<Integer> list = new ArrayList<>();

	
	list.add(1);
	list.add(2);
	list.add(3);
	list.add(4);
		
	
	if(list.indexOf(1)>=0)
		System.out.println("7 Dhoni exists in the ArrayList");
		
	else
		System.out.println("7 Dhoni does not exist in the ArrayList");
		
	if(list.indexOf(6)>=0)
		System.out.println("18 Virat exists in the ArrayList");
		
	else
		System.out.println("18 Virat not exist in the ArrayList");
		
	}
}
