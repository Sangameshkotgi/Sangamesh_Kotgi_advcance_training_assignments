package program8;

public class ThreadCounter {

	public static void main(String args[])

	{

	Counter counter = new Counter(28);

	counter.run();

	}



	}
