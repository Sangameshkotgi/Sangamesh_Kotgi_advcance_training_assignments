package program12;



import java.util.*;
 
public class Repeated_element {

    static void printFirstRepeating(int arr[])
    {
       
        int min = -1;
 

        HashSet<Integer> set = new HashSet<>();
 
       
        for (int i=arr.length-1; i>=0; i--)
        {
            
            if (set.contains(arr[i]))
                min = i;
 
            else   
                set.add(arr[i]);
        }
 
       
        if (min != -1)
          System.out.println("The first repeating element is " + arr[min]);
        else
          System.out.println("There are no repeating elements");
    }
 
    
    public static void main (String[] args) throws java.lang.Exception
    {
        int arr[] = {1, 4, 5, 12, 6, 4, 5, 9, 3 };
        printFirstRepeating(arr);
        
        int arr1[] = {2, 3, 6, 8, 3, 4, 5, 9, 10};
        printFirstRepeating(arr1);
        
        
    }
}


